#################
Twitter Game Book
#################
.. include:: ../../README.rst
    :start-after: Twitter Game Book
    :end-before: Installation

.. toctree::
    :maxdepth: 2
    :caption: Contents:

    usage
    twgamebook

Change Log
==========

.. include:: ../../README.rst
    :start-after: Change Log
    :end-before: About Inklewriter JSON files

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
