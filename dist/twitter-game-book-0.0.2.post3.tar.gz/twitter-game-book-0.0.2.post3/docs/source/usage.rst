#####
Usage
#####

Installation
============

.. include:: ../../README.rst
    :start-after: Installation
    :end-before: Usage

Let's Go
========
.. literalinclude:: ../../twgamebook/command_line.py
    :start-after: """
    :end-before: """

.. include:: ../../README.rst
    :start-after: Usage
    :end-before: To Do